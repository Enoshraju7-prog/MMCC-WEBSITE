globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/JXIqoEEdgTMmFQftwIbrp/_buildManifest.js",
    "static/JXIqoEEdgTMmFQftwIbrp/_ssgManifest.js",
    "static/JXIqoEEdgTMmFQftwIbrp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/033g87j5nlof8.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10~x95jhs6ns3.js",
    "static/chunks/062hzijh369a_.js",
    "static/chunks/turbopack-0jx9k3z..kj7r.js"
  ]
};
